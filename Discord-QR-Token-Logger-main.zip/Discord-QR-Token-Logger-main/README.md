# Discord QR Token Logger

![forthebadge](https://forthebadge.com/images/badges/made-with-python.svg)
![forthebadge](http://forthebadge.com/images/badges/built-with-love.svg)
![author](https://svgshare.com/i/mg6.svg)

![GitHub](https://img.shields.io/github/license/9P9/Discord-QR-Token-Logger)
![GitHub contributors](https://img.shields.io/github/contributors/9P9/Discord-QR-Token-Logger)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=shields)](http://makeapullrequest.com)
![GitHub issues](https://img.shields.io/github/issues/9P9/Discord-QR-Token-Logger)
![GitHub pull requests](https://img.shields.io/github/issues-pr/9P9/Discord-QR-Token-Logger)
![Maintenance](https://img.shields.io/maintenance/yes/2022)
![GitHub commit activity](https://img.shields.io/github/commit-activity/m/9P9/Discord-QR-Token-Logger)

A python script that generates a scam nitro QR code which can grab a victim's authentication token if scanned. Developed to show how social engineering is performed.

*If you're interested in knowing the powerlevel configuration to get this prompt, you can contact me [here](https://mouadessalim.xyz/#contact).*

![Discord QR Token Grabber](https://user-images.githubusercontent.com/38190847/187040712-92f4c796-c655-47a2-abb2-7f4519d1dab7.png)

<p align="center">
<i>Love the tool? Please consider <strong>donating</strong> 💸 to help it improve!</i>
</p>

<p align="center">
<a href='https://ko-fi.com/mouadessalim' target='_blank'><img height='30' width="115" src='https://cdn.ko-fi.com/cdn/kofi3.png?v=2' alt='Buy Coffee for mouadessalim' />
</a>
<a href="https://www.buymeacoffee.com/mouadessalim" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" height="30" width="115" style="border-radius:1px" />
</p>

## ❗ Disclaimer
- **For Educational Purposes Only**
- **We decline any responsability in case of misuse of this code.**

# 📖 Table of contents

- [Usage](#-usage)
  - [Without Discord features](#without-discord-webhook)
  - [With Discord features](#with-discord-webhook)
- [Installation](#-installation)
  - [Dependencies](#dependencies)
  - [Supported Platforms](#supported-platforms)
- [Contributing](#contributing)
  - [Authors](#authors-)
- [License](#-license)
- [Other Project](#-other-projects)

# 📈 Usage

To use the script, run `install_requirements.bat` if needed, then run `main.py`. The scam image will appear as `discord_gift.png` in the directory. 

> ⚠️ __The Qr generated image is available for only `2 min`!__ ⚠️

There are two ways to use the script:

### Without Discord Webhook

Without a Discord Webhook, you can only get target token. You must enter `n` when prompted.

<img src="https://user-images.githubusercontent.com/38190847/187074516-29a22055-96a0-40f9-9d79-8a69834ab039.png" width="500">

### With Discord Webhook

To use a Discord Webhook you must enter `y` when prompted.

<img src="https://user-images.githubusercontent.com/38190847/187074586-d5c0a8f5-c96b-45bb-ac96-42550c2f1ae4.png" width="500">

With a Discord Webhook, you will be able to get much more target information. The target information shown includes:

- User token informations :
  - 👑 Username
  - 🆔 User ID
  - 📧 Mail 
  - 📞 Phone 
  - 🤑 Nitro 
- Payment info :
  - 💳 Brand (Visa / Mastecard / PayPal)
  - ℹ/📩 Last 4 digits / PayPal mail
  - 📅 Expiration
- Billing adress :
  - 📛 Name
  - 🏠 1️⃣ Address Line 1
  - 🏠 2️⃣ Address Line 2
  - 🏳 Country
  - 🚩 State
  - 🏙 City
  - 📮 Postal code

# 🛠 Installation

For installation, there are a few requirements. You must follow these steps to avoid all python interpreter errors.

## Dependencies

- Chrome: **be sure to have the latest version**.
- Python 3.9+
- Python Modules (launch `install_requirements.bat`)

After installing all dependencies, you can start the script 🥳.

## Supported Platforms
- Windows 11 - `supported but not tested`
- Windows 10 - `supported and tested`
- Windows 8 - `supported but not tested`
- Windows 7 - `supported but not tested`

# ✨Contributing

Your contributions are always welcome! If you contribute we will show your account in this README! 

_Please have a look at the [contribution guidelines](CONTRIBUTING.md) first._ 🎉

## Authors ❤

<a href="https://github.com/9P9/Discord-QR-Token-Logger/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=9P9/Discord-QR-Token-Logger" />
</a>
<br>
<br>

> **Working on your first Pull Request?** You can learn how from this *free* series [How to Contribute to an Open Source Project on GitHub](https://kcd.im/pull-request)

# 📝 License

The actual repository is _unlicensed_, it mean **all rights are reserved**. You cannot modify or redistribute this code without **explicit** permission from the copyright [holders](https://github.com/9P9/Discord-QR-Token-Logger/graphs/contributors). 

_Violating this rule may lead our intervention according to the [Github Terms of Service — User-Generated Content — Section D.3](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service#3-ownership-of-content-right-to-post-and-license-grants) using the [Content Removal Policies — DMCA Takedown Policy](https://docs.github.com/en/site-policy/content-removal-policies/dmca-takedown-policy#what-is-the-dmca)_.

# 💡 Other projects

If you love this repository you may be interested in these projects:

[![Readme Card](https://github-readme-stats.vercel.app/api/pin/?username=mouadessalim&repo=CookedGrabber&show_owner=true)](https://github.com/mouadessalim/CookedGrabber)

[![Readme Card](https://github-readme-stats.vercel.app/api/pin/?username=the-cult-of-integral&repo=discord-raidkit&show_owner=true)](https://github.com/the-cult-of-integral/discord-raidkit)
